﻿Public Class Form2


    Private Sub Ajout(ByVal LastN_user As String, ByVal FirstN_user As String, ByVal DateN_user As String, ByVal Email_user As String, ByVal Téléphone_user As String, ByVal Spécialité_user As String,
             ByVal NiveauD_user As String, ByVal DateD_user As String, ByVal DateF_user As String)

        DataGridView1.ColumnCount = 9
        DataGridView1.Columns(0).Name = "Nom"
        DataGridView1.Columns(1).Name = "Prénom"
        DataGridView1.Columns(2).Name = "Date de naissance"
        DataGridView1.Columns(3).Name = "Email"
        DataGridView1.Columns(4).Name = "Téléphone"
        DataGridView1.Columns(5).Name = "Spésialité"
        DataGridView1.Columns(6).Name = "Niveau d'étude"
        DataGridView1.Columns(7).Name = "Date de début"
        DataGridView1.Columns(8).Name = "Date de fin"

        Dim ligne As New DataGridViewRow
        Dim celluleText As New DataGridViewTextBoxCell

        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = LastN_user
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = FirstN_user
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = DateN_user
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = Email_user
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = Téléphone_user
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = Spécialité_user
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = NiveauD_user
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = DateD_user
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = DateF_user
        ligne.Cells.Add(celluleText)
        DataGridView1.Rows.Add(ligne)
    End Sub
    Private Sub Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Add.Click
        If String.IsNullOrEmpty(LastN_user.Text) OrElse
           String.IsNullOrEmpty(FirstN_user.Text) OrElse
           String.IsNullOrEmpty(DateN_user.Text) OrElse
           String.IsNullOrEmpty(TéLéphone_user.Text) OrElse
           String.IsNullOrEmpty(Email_user.Text) OrElse
           String.IsNullOrEmpty(Spécialité_user.Text) OrElse
           String.IsNullOrEmpty(NiveauD_user.Text) OrElse
           String.IsNullOrEmpty(DateD_user.Text) OrElse
           String.IsNullOrEmpty(DateF_user.Text) Then
            MessageBox.Show("veuillez saisir tous les champs")
        ElseIf IsNumeric(LastN_user.Text) = True Then
            MessageBox.Show("veuillez saisir un nom valide")
        ElseIf IsNumeric(FirstN_user.Text) = True Then
            MessageBox.Show("veuillez saisir un prénom valide")
        ElseIf IsNumeric(TéLéphone_user.Text) = False Then
            MessageBox.Show("veuillez saisir un numéro de téléphone valide")
        Else
            Call Ajout(LastN_user.Text, FirstN_user.Text, DateN_user.Text, Email_user.Text, TéLéphone_user.Text, Spécialité_user.Text,
                       NiveauD_user.Text, DateD_user.Text, DateF_user.Text)
        End If
        LastN_user.Text = " "
        FirstN_user.Text = " "
        Email_user.Text = " "
        TéLéphone_user.Text = " "
        Spécialité_user.Text = " "
        NiveauD_user.Text = " "
    End Sub


    Private Sub Modify_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Modify.Click
        Dim index As Integer
        Dim ligne As New DataGridViewRow
        If String.IsNullOrEmpty(LastN_user.Text) OrElse
           String.IsNullOrEmpty(FirstN_user.Text) OrElse
           String.IsNullOrEmpty(DateN_user.Text) OrElse
           String.IsNullOrEmpty(Email_user.Text) OrElse
           String.IsNullOrEmpty(TéLéphone_user.Text) OrElse
           String.IsNullOrEmpty(Spécialité_user.Text) OrElse
           String.IsNullOrEmpty(NiveauD_user.Text) OrElse
           String.IsNullOrEmpty(DateD_user.Text) OrElse
           String.IsNullOrEmpty(DateF_user.Text) Then
            MessageBox.Show("veuillez saisir tous les champs")
        Else
            index = DataGridView1.CurrentCell.RowIndex
            ligne = DataGridView1.Rows(index)
            ligne.Cells(0).Value = LastN_user.Text
            ligne.Cells(1).Value = FirstN_user.Text
            ligne.Cells(2).Value = DateN_user.Text
            ligne.Cells(3).Value = Email_user.Text
            ligne.Cells(4).Value = TéLéphone_user.Text
            ligne.Cells(5).Value = Spécialité_user.Text
            ligne.Cells(6).Value = NiveauD_user.Text
            ligne.Cells(7).Value = DateD_user.Text
            ligne.Cells(8).Value = DateF_user.Text
        End If
        LastN_user.Text = " "
        FirstN_user.Text = " "
        Email_user.Text = " "
        TéLéphone_user.Text = " "
        Spécialité_user.Text = " "
        NiveauD_user.Text = " "




    End Sub

    Private Sub Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Delete.Click
        Dim index As Integer
        index = DataGridView1.CurrentCell.RowIndex


        Dim confirmResult As DialogResult = MessageBox.Show("Êtes-vous sûr de vouloir supprimer les informations des stagiaires ?", "Confirmation de suppression", MessageBoxButtons.YesNo)

        If confirmResult = DialogResult.Yes Then

            DataGridView1.Rows.RemoveAt(index)

            MessageBox.Show("Les informations des stagiaires ont été supprimées avec succès.", "Suppression réussie")
        End If
    End Sub


    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim i As Integer
        Dim ligne As New DataGridViewRow
        i = DataGridView1.CurrentCell.RowIndex
        ligne = DataGridView1.Rows(i)
        LastN_user.Text = ligne.Cells(0).Value
        FirstN_user.Text = ligne.Cells(1).Value
        DateN_user.Text = ligne.Cells(2).Value
        Email_user.Text = ligne.Cells(3).Value
        TéLéphone_user.Text = ligne.Cells(4).Value
        Spécialité_user.Text = ligne.Cells(5).Value
        NiveauD_user.Text = ligne.Cells(6).Value
        DateD_user.Text = ligne.Cells(7).Value
        DateF_user.Text = ligne.Cells(8).Value



    End Sub

    Private Sub AddCongé_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddCongé.Click
        Dim form3 As New Form3()
        form3.Show()
        Me.Hide()
    End Sub






End Class