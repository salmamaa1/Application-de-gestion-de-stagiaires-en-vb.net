﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.AddCongé = New System.Windows.Forms.Button()
        Me.Delete = New System.Windows.Forms.Button()
        Me.Modify = New System.Windows.Forms.Button()
        Me.Add = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.DateN_user = New System.Windows.Forms.DateTimePicker()
        Me.DateF_user = New System.Windows.Forms.DateTimePicker()
        Me.DateD_user = New System.Windows.Forms.DateTimePicker()
        Me.NiveauD_user = New System.Windows.Forms.TextBox()
        Me.FirstN_user = New System.Windows.Forms.TextBox()
        Me.TéLéphone_user = New System.Windows.Forms.TextBox()
        Me.Spécialité_user = New System.Windows.Forms.TextBox()
        Me.LastN_user = New System.Windows.Forms.TextBox()
        Me.Email_user = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(287, 603)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(0, 20)
        Me.Label12.TabIndex = 54
        '
        'AddCongé
        '
        Me.AddCongé.BackColor = System.Drawing.Color.LightSteelBlue
        Me.AddCongé.Location = New System.Drawing.Point(509, 603)
        Me.AddCongé.Name = "AddCongé"
        Me.AddCongé.Size = New System.Drawing.Size(190, 94)
        Me.AddCongé.TabIndex = 53
        Me.AddCongé.Text = "Ajouter un congé"
        Me.AddCongé.UseVisualStyleBackColor = False
        '
        'Delete
        '
        Me.Delete.BackColor = System.Drawing.Color.Silver
        Me.Delete.Location = New System.Drawing.Point(1287, 505)
        Me.Delete.Name = "Delete"
        Me.Delete.Size = New System.Drawing.Size(166, 82)
        Me.Delete.TabIndex = 52
        Me.Delete.Text = "Supprimer"
        Me.Delete.UseVisualStyleBackColor = False
        '
        'Modify
        '
        Me.Modify.BackColor = System.Drawing.Color.Silver
        Me.Modify.Location = New System.Drawing.Point(1287, 361)
        Me.Modify.Name = "Modify"
        Me.Modify.Size = New System.Drawing.Size(166, 82)
        Me.Modify.TabIndex = 51
        Me.Modify.Text = "Modifier"
        Me.Modify.UseVisualStyleBackColor = False
        '
        'Add
        '
        Me.Add.BackColor = System.Drawing.Color.Silver
        Me.Add.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Add.Location = New System.Drawing.Point(1287, 221)
        Me.Add.Name = "Add"
        Me.Add.Size = New System.Drawing.Size(166, 82)
        Me.Add.TabIndex = 50
        Me.Add.Text = "Ajouter"
        Me.Add.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.DodgerBlue
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(23, 188)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(1207, 399)
        Me.DataGridView1.TabIndex = 49
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(1016, 125)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(87, 20)
        Me.Label11.TabIndex = 48
        Me.Label11.Text = "Date de fin"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(1016, 88)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(111, 20)
        Me.Label10.TabIndex = 47
        Me.Label10.Text = "Date de début"
        '
        'DateN_user
        '
        Me.DateN_user.Location = New System.Drawing.Point(195, 125)
        Me.DateN_user.Name = "DateN_user"
        Me.DateN_user.Size = New System.Drawing.Size(241, 26)
        Me.DateN_user.TabIndex = 46
        '
        'DateF_user
        '
        Me.DateF_user.Location = New System.Drawing.Point(1175, 125)
        Me.DateF_user.Name = "DateF_user"
        Me.DateF_user.Size = New System.Drawing.Size(250, 26)
        Me.DateF_user.TabIndex = 45
        '
        'DateD_user
        '
        Me.DateD_user.Location = New System.Drawing.Point(1175, 88)
        Me.DateD_user.Name = "DateD_user"
        Me.DateD_user.Size = New System.Drawing.Size(250, 26)
        Me.DateD_user.TabIndex = 44
        '
        'NiveauD_user
        '
        Me.NiveauD_user.Location = New System.Drawing.Point(674, 122)
        Me.NiveauD_user.Name = "NiveauD_user"
        Me.NiveauD_user.Size = New System.Drawing.Size(243, 26)
        Me.NiveauD_user.TabIndex = 43
        '
        'FirstN_user
        '
        Me.FirstN_user.Location = New System.Drawing.Point(195, 82)
        Me.FirstN_user.Name = "FirstN_user"
        Me.FirstN_user.Size = New System.Drawing.Size(241, 26)
        Me.FirstN_user.TabIndex = 42
        '
        'TéLéphone_user
        '
        Me.TéLéphone_user.BackColor = System.Drawing.SystemColors.Window
        Me.TéLéphone_user.Location = New System.Drawing.Point(674, 43)
        Me.TéLéphone_user.Name = "TéLéphone_user"
        Me.TéLéphone_user.Size = New System.Drawing.Size(243, 26)
        Me.TéLéphone_user.TabIndex = 41
        '
        'Spécialité_user
        '
        Me.Spécialité_user.Location = New System.Drawing.Point(674, 82)
        Me.Spécialité_user.Name = "Spécialité_user"
        Me.Spécialité_user.Size = New System.Drawing.Size(243, 26)
        Me.Spécialité_user.TabIndex = 40
        '
        'LastN_user
        '
        Me.LastN_user.Location = New System.Drawing.Point(195, 43)
        Me.LastN_user.Name = "LastN_user"
        Me.LastN_user.Size = New System.Drawing.Size(241, 26)
        Me.LastN_user.TabIndex = 39
        '
        'Email_user
        '
        Me.Email_user.Location = New System.Drawing.Point(1175, 47)
        Me.Email_user.Name = "Email_user"
        Me.Email_user.Size = New System.Drawing.Size(250, 26)
        Me.Email_user.TabIndex = 38
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(1016, 49)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 20)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Email"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(923, 53)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 20)
        Me.Label8.TabIndex = 36
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(923, 53)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 20)
        Me.Label7.TabIndex = 35
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(505, 125)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(114, 20)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Niveau d'étude"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(511, 88)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 20)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Spécialité"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(505, 49)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 20)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "Téléphone"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(47, 125)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(142, 20)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "Date de naissance"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(47, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 20)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "Prénom"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(47, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 20)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "Nom"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1621, 709)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.AddCongé)
        Me.Controls.Add(Me.Delete)
        Me.Controls.Add(Me.Modify)
        Me.Controls.Add(Me.Add)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.DateN_user)
        Me.Controls.Add(Me.DateF_user)
        Me.Controls.Add(Me.DateD_user)
        Me.Controls.Add(Me.NiveauD_user)
        Me.Controls.Add(Me.FirstN_user)
        Me.Controls.Add(Me.TéLéphone_user)
        Me.Controls.Add(Me.Spécialité_user)
        Me.Controls.Add(Me.LastN_user)
        Me.Controls.Add(Me.Email_user)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.Text = "Application de gestion des stagiaires"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents AddCongé As System.Windows.Forms.Button
    Friend WithEvents Delete As System.Windows.Forms.Button
    Friend WithEvents Modify As System.Windows.Forms.Button
    Friend WithEvents Add As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents DateN_user As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateF_user As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateD_user As System.Windows.Forms.DateTimePicker
    Friend WithEvents NiveauD_user As System.Windows.Forms.TextBox
    Friend WithEvents FirstN_user As System.Windows.Forms.TextBox
    Friend WithEvents TéLéphone_user As System.Windows.Forms.TextBox
    Friend WithEvents Spécialité_user As System.Windows.Forms.TextBox
    Friend WithEvents LastN_user As System.Windows.Forms.TextBox
    Friend WithEvents Email_user As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
