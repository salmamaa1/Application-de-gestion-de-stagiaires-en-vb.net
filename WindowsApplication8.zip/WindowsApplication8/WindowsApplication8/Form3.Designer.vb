﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DateD = New System.Windows.Forms.DateTimePicker()
        Me.DateF = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Motif = New System.Windows.Forms.TextBox()
        Me.CreateCongé = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Prénom = New System.Windows.Forms.TextBox()
        Me.NOM = New System.Windows.Forms.TextBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DateD
        '
        Me.DateD.Location = New System.Drawing.Point(268, 235)
        Me.DateD.Name = "DateD"
        Me.DateD.Size = New System.Drawing.Size(200, 26)
        Me.DateD.TabIndex = 0
        '
        'DateF
        '
        Me.DateF.Location = New System.Drawing.Point(268, 291)
        Me.DateF.Name = "DateF"
        Me.DateF.Size = New System.Drawing.Size(200, 26)
        Me.DateF.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(58, 235)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(181, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Date de début du congé"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(58, 291)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(157, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Date de fin du congé"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(58, 182)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Motif"
        '
        'Motif
        '
        Me.Motif.Location = New System.Drawing.Point(268, 179)
        Me.Motif.Name = "Motif"
        Me.Motif.Size = New System.Drawing.Size(200, 26)
        Me.Motif.TabIndex = 5
        '
        'CreateCongé
        '
        Me.CreateCongé.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.CreateCongé.Location = New System.Drawing.Point(744, 125)
        Me.CreateCongé.Name = "CreateCongé"
        Me.CreateCongé.Size = New System.Drawing.Size(155, 94)
        Me.CreateCongé.TabIndex = 6
        Me.CreateCongé.Text = "Créer un congé"
        Me.CreateCongé.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.DodgerBlue
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(62, 346)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(837, 336)
        Me.DataGridView1.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(60, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 20)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Nom"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(58, 125)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 20)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Prénom"
        '
        'Prénom
        '
        Me.Prénom.Location = New System.Drawing.Point(268, 125)
        Me.Prénom.Name = "Prénom"
        Me.Prénom.Size = New System.Drawing.Size(200, 26)
        Me.Prénom.TabIndex = 10
        '
        'NOM
        '
        Me.NOM.Location = New System.Drawing.Point(268, 75)
        Me.NOM.Name = "NOM"
        Me.NOM.Size = New System.Drawing.Size(200, 26)
        Me.NOM.TabIndex = 11
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1136, 694)
        Me.Controls.Add(Me.NOM)
        Me.Controls.Add(Me.Prénom)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.CreateCongé)
        Me.Controls.Add(Me.Motif)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DateF)
        Me.Controls.Add(Me.DateD)
        Me.Name = "Form3"
        Me.Text = "demande d'un congé"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DateD As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateF As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Motif As System.Windows.Forms.TextBox
    Friend WithEvents CreateCongé As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Prénom As System.Windows.Forms.TextBox
    Friend WithEvents NOM As System.Windows.Forms.TextBox
End Class
