﻿Public Class Form3

    Private Sub Ajout(ByVal NOM As String, ByVal Prénom As String, ByVal DateD As String, ByVal DateF As String, ByVal Motif As String)

        DataGridView1.ColumnCount = 5
        DataGridView1.Columns(0).Name = "Nom"
        DataGridView1.Columns(1).Name = "Prénom"
        DataGridView1.Columns(2).Name = "Date de début du congé"
        DataGridView1.Columns(3).Name = "Date de fin du congé"
        DataGridView1.Columns(4).Name = "Motif"


        Dim ligne As New DataGridViewRow
        Dim celluleText As New DataGridViewTextBoxCell
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = NOM
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = Prénom
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = DateD
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = DateF
        ligne.Cells.Add(celluleText)
        celluleText = New DataGridViewTextBoxCell
        celluleText.Value = Motif
        ligne.Cells.Add(celluleText)
        DataGridView1.Rows.Add(ligne)
    End Sub
    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim i As Integer
        Dim ligne As New DataGridViewRow
        i = DataGridView1.CurrentCell.RowIndex
        ligne = DataGridView1.Rows(i)
        NOM.Text = ligne.Cells(0).Value
        Prénom.Text = ligne.Cells(1).Value
        DateD.Text = ligne.Cells(2).Value
        DateF.Text = ligne.Cells(3).Value
        Motif.Text = ligne.Cells(4).Value
    End Sub

    Private Sub CreateCongé_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateCongé.Click
        If String.IsNullOrEmpty(NOM.Text) OrElse
             String.IsNullOrEmpty(Prénom.Text) OrElse
            String.IsNullOrEmpty(DateD.Text) OrElse
            String.IsNullOrEmpty(DateF.Text) OrElse
            String.IsNullOrEmpty(Motif.Text) Then
            MessageBox.Show("veuillez saisir tous les champs")
        Else
            Call Ajout(NOM.Text, Prénom.Text, DateD.Text, DateF.Text, Motif.Text)
        End If
        NOM.Text = " "
        Prénom.Text = " "
        Motif.Text = " "

    End Sub


End Class